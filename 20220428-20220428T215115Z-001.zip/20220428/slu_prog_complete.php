<html>
<body>
<?php
$Last =$_GET["Last"];
$First =$_GET["First"];
$User =$_GET["User"];
$Password =$_GET["Password"];
print "you entered $Last as your last name <br>";
print "you entered $First as your first name <br>";
print "you entered $Password as your password <br>";

if ($User == "bob" && $Password == "bob1") {
	print "Access allowed";
	print "<A href='slu_access.html'> slu_access </A>";
	exit
	}

if ($User == "jim" && $Password == "jim1") {
	print "Access allowed";
	print "<A href='slu_access.html'> slu_access </A>";
	exit
	}

print "Access denied";
	exit

?>
</body>
</html>
