<html>
<body>
<?php
$Last =$_GET["Last"];
$First =$_GET["First"];
$User =$_GET["User"];
$Password =$_GET["Password"];
$Discount =$_GET["Discount"];
$order =$_GET["order"];
$Cost = $order * 25 - ($order *25 * $discount);
print " T-shirts are 25 dollars each<br>";
print " Your cost will be: $Cost dollars <br>";
print "Thank you $First  <br>";

/*
*/

?>
</body>
</html>
