<html>
<body>
<?php
print "Hello world </br>";
?>
</body>
</html>
