<html>
<body>
<?php
$Last =$_GET["Last"];
$First =$_GET["First"];
$Email =$_GET["email"];
$Password =$_GET["Password"];
$Discount =$_GET["Discount"];
$order =$_GET["order"];
$Cost = $order * 25 - ($order *25 * $discount);
print " T-shirts are 25 dollars each<br>";
print " Your cost will be: $Cost dollars <br>";
print "Thank you $First  <br>";

/*
*/
if ($Email == "leroy@slu.edu" && $Password == "leroy1") {
	print "Access allowed";
	print "<A href='slu_access.html'> slu_access </A>";
	exit;
	}elseif ($Email == "leroy@slu.edu" ){
		print "User name correct but not password";
		exit;
		}elseif ($Password == "leroy1" ){
			print "Password correct but not username";
			exit;
		}
	

if ($Email == "Charlene@slu.edu" && $Password == "Charlene1") {
	print "Access allowed";
	print "<A href='slu_access.html'> slu_access </A>";
	exit;
	}

print "Access denied";
	exit
?>
</body>
</html>
