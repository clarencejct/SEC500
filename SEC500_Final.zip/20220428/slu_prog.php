<html>
<body>
<?php
$Last =$_GET["Last"];
$First =$_GET["First"];
$User =$_GET["User"];
$Password =$_GET["Password"];
$Discount =$_GET["Discount"];
print "the discount was hidden discount:$Discount <br>";
print "you entered $Last as your last name <br>";
print "you entered $Last as your last name <br>";
print "you entered $First as your first name <br>";
print "you entered $Password as your password <br>";

/*
*/
if ($User == "bob" && $Password == "bob1") {
	print "Access allowed";
	print "<A href='slu_access.html'> slu_access </A>";
	exit;
	}elseif ($User == "bob" ){
		print "User name correct but not password";
		exit;
		}elseif ($Password == "bob1" ){
			print "Password correct but not username";
			exit;
		}
	

if ($User == "jim" && $Password == "jim1") {
	print "Access allowed";
	print "<A href='slu_access.html'> slu_access </A>";
	exit;
	}

print "Access denied";
	exit
?>
</body>
</html>
