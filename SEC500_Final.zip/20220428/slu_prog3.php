<html>
<body>
<?php
$Last =$_GET["Last"];
$First =$_GET["First"];
$Email =$_GET["email"];
$Password =$_GET["Password"];
$Discount =$_GET["Discount"];
$order =$_GET["Order"];
$Cost = $order * 25 - ($order *25 * $discount);

/*
*/
if ($Email == "leroy@slu.edu" && $Password == "leroy1") {
	print " T-shirts are 25 dollars each<br>";
	print " Your cost will be: $Cost dollars <br>";
	print "Thank you $First  <br>";
	exit;
	}elseif ($Email == "Charlene@slu.edu" && $Password == "Charlene1") 
		{
		print " T-shirts are 25 dollars each<br>";
		print " Your cost will be: $Cost dollars <br>";
		print "Thank you $First  <br>";
		exit;
		}else {
		print "no access <br>";
	        print "<a href='/sluform3.html'> start over </a>";
		exit;
		}
	
	

?>
</body>
</html>
