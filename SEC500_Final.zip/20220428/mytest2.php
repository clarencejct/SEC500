<html>
<body>
<?php
print "Hello world </br>";
$Last =$_GET["Last"];
$First =$_GET["First"];
$Password =$_GET["Password"];
print "you entered $Last as your last name <br>";
print "you entered $First as your first name <br>";
print "you entered $Password as your password <br>";

?>
</body>
</html>
