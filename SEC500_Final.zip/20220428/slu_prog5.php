<html>
<body>
<?php
$Last =$_POST["Last"];
$First =$_POST["First"];
$Email =$_POST["Email"];
$Password =$_POST["Password"];
$Discount =$_POST["Discount"];
$order =$_POST["Order"];
$Cost = $order * 25 - ($order *25 * $discount);

/*
*/
if ($Email == "leroy@slu.edu" && $Password == "leroy1") {
	print " T-shirts are 25 dollars each<br>";
	print " Your cost will be: $Cost dollars <br>";
	print "Thank you $First  <br>";
	exit;
	}elseif ($Email == "Charlene@slu.edu" && $Password == "Charlene1") 
		{
		print " T-shirts are 25 dollars each<br>";
		print " Your cost will be: $Cost dollars <br>";
		print "Thank you $First  <br>";
		exit;
		}else {
		print "no access <br>";
		print "Microsoft SQL server version 1.0 has found a mistake on line 10<br>";
		print "Contact Bob Johnson at 314-555-5555 or email bob@slu.edu <br>";
	        print "<a href='/sluform4.html'> start over </a>";
		exit;
		}
	

	

?>
</body>
</html>
