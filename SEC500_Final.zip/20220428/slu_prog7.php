<html>
<body>
<?php
$Last =$_POST["Last"];
$First =$_POST["First"];
$Email =$_POST["Email"];
$Password =$_POST["Password"];
$Discount =$_POST["Discount"];
$Acct =$_POST["Acct"];
$order =$_POST["Order"];
$Cost = $order * 25 - ($order *25 * $discount);
$Pattern1 = "/Johnson/i"
$Pattern2 = "/Jackson/i"
$Pattern3 = "/Brown/i"
$Pattern4 = "/Moore/i"
$Pattern5 = "/BigData/"
/*
*/

if (preg_match ($Pattern1,$Last) ){
	print " Jim Johnson 4123 tavern street St. Louis MO 63000";
}
if (preg_match ($Pattern2,$Last) ){
	print " Jim Jackson 4123 tavern street St. Louis MO 63000";
}
if (preg_match ($Pattern3,$Last) ){
	print " Jim Brown 4123 tavern street St. Louis MO 63000";
}
if (preg_match ($Pattern4,$Last) ){
	print " Jim Moore 4123 tavern street St. Louis MO 63000";
}

if (preg_match ($Pattern5,$Last) ){
	print " Jim Johnson 4123 tavern street St. Louis MO 63000 <br>";
	print " Jim Jackson 4123 tavern street St. Louis MO 63000<br>";
	print " Jim Brown 4123 tavern street St. Louis MO 63000 <br>";
	print " Jim Moore 4123 tavern street St. Louis MO 63000";
}
	

	

?>
</body>
</html>
